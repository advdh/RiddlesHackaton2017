﻿namespace RiddlesHackaton2017.Models
{
	public enum GameStatus
	{
		Busy,
		Won,
		Lost,
		Draw,
	}
}
