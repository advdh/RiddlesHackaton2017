﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
[assembly: AssemblyTitle("RiddlesHackaton2017")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("RiddlesHackaton2017")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.0.0.0")]
